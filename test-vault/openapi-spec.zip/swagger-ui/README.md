# Swagger UI

This folder contains resources from [Swagger UI](https://github.com/swagger-api/swagger-ui).

Swagger UI is licensed under the [Apache License 2.0](LICENSE).